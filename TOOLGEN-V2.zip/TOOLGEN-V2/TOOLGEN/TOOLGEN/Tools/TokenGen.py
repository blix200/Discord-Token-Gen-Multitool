import os

# Change directory to the Token Gen folder
os.chdir('Tools/Token Gen')

# Run the TokenGen.py script
os.system('python TokenGen.py')
