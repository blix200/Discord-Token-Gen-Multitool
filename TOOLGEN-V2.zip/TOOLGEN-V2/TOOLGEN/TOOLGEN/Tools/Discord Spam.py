import os

# Change directory to the Token Gen folder
os.chdir('Tools/Discord Spam')

# Run the TokenGen.py script
os.system('python DiscordSpam.py')
