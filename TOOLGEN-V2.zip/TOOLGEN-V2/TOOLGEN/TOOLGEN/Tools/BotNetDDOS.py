import webbrowser

# Set the URL of the GitHub page you want to open
url = "https://github.com/skavngr/netbot"

# Open the URL in your default web browser
webbrowser.open_new_tab(url)
